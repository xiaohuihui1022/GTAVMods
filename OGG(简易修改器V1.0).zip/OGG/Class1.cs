﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using NativeUI;
using GTA.Native;
using System.Windows.Forms;
using GTA;


//namespace GTAV_Script_Example
//{
//}
//命名空间可以不写，这里我备注掉了

internal class OGG : Script   //注意一定要继承“Script”类
{
    //该函数为构造函数，函数名跟类名同名，该类被加载后执行此函数
    public OGG()
    {
        //Tick += OnTick; //刷新事件
        base.KeyUp += OnKeyUp; //按键按下事件
        Interval = 10; //刷新事件的间隔时间，单位毫秒
    }
    private void OnKeyUp(object sender, KeyEventArgs e)
    {
        // 检测按键K是否被按下 如果按下 跳出下面这些东西 如果没有 则继续
        if (e.KeyCode == Keys.K)
        {
            this.GN();
            UI.Notify("~g~車輛爆炸~w~: 修改菜單已打開");
            UI.Notify("~g~灰灰提示~w~: 切勿在線上的時候使用此修改器");
        }
    }
    //修改器功能区
    private UIMenu GN()
    {
        this.prisMenu = new UIMenu("OGG", "~b~主菜單");
        this._menuPool.Add(this.prisMenu);

        UIMenuItem uimenuItem2 = new UIMenuItem("主角修改", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem2);
        this.prisMenu.BindMenuToItem(this.ZJ(), uimenuItem2);

        UIMenuItem uimenuItem = new UIMenuItem("車輛爆炸", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem);
        this.prisMenu.BindMenuToItem(this.VB(), uimenuItem);

        return this.GNMenu;
    }

    //車輛爆炸
    private UIMenu VB()
    {
        this.prisMenu = new UIMenu("車輛爆炸", "~b~主菜單");
        this._menuPool.Add(this.prisMenu);
        UIMenuItem uimenuItem = new UIMenuItem("200米內的車輛爆炸", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem);
        UIMenuItem uimenuItem2 = new UIMenuItem("400米內的車輛爆炸", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem2);
        UIMenuItem uimenuItem3 = new UIMenuItem("600米內的車輛爆炸", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem3);
        UIMenuItem uimenuItem4 = new UIMenuItem("800米內的車輛爆炸", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem4);
        this.prisMenu.OnItemSelect += this.OnItemSelect;
        this.prisMenu.OnCheckboxChange += this.OnCheckboxChange;
        this.prisMenu.RefreshIndex();
        this.prisMenu.BindMenuToItem(this.CB200M(), uimenuItem);
        this.prisMenu.BindMenuToItem(this.CB400M(), uimenuItem2);
        this.prisMenu.BindMenuToItem(this.CB600M(), uimenuItem3);
        this.prisMenu.BindMenuToItem(this.CB800M(), uimenuItem4);
        this.prisMenu.Visible = !this.prisMenu.Visible;
        return this.prisMenu;
    }

    //車輛爆炸附屬
    private UIMenu CB200M()
    {
        UI.Notify("~g~灰灰提示~w~: 切勿在車上的時候使用此功能");

        Ped player = Game.Player.Character;

        Vehicle[] vehicles = World.GetNearbyVehicles(player, 200f);

        vehicles[0].Explode();

        return this.CB200Menu;
    }
    //車輛爆炸附屬
    private UIMenu CB400M()
    {
        UI.Notify("~g~灰灰提示~w~: 切勿在車上的時候使用此功能");

        Ped player = Game.Player.Character;

        Vehicle[] vehicles = World.GetNearbyVehicles(player, 400f);

        vehicles[0].Explode();

        return this.CB400Menu;
    }
    //車輛爆炸附屬
    private UIMenu CB600M()
    {
        UI.Notify("~g~灰灰提示~w~: 切勿在車上的時候使用此功能");

        Ped player = Game.Player.Character;

        Vehicle[] vehicles = World.GetNearbyVehicles(player, 600f);

        vehicles[0].Explode();

        return this.CB600Menu;
    }
    //車輛爆炸附屬
    private UIMenu CB800M()
    {
        UI.Notify("~g~灰灰提示~w~: 切勿在車上的時候使用此功能");

        Ped player = Game.Player.Character;

        Vehicle[] vehicles = World.GetNearbyVehicles(player, 800f);

        vehicles[0].Explode();
        
        return this.CB800Menu;
    }
    private void OnItemSelect(UIMenu sender, UIMenuItem selectedItem, int index)
    {
    }
    // OnCheckboxChange(不晓得啥意思 不用改就好)
    public void OnCheckboxChange(UIMenu sender, UIMenuCheckboxItem checkbox, bool Checked)
    {
    }

    //主角修改
    private UIMenu ZJ()
    {
        UIMenuItem uimenuItem = new UIMenuItem("玩家錢數增加五千萬", "bilibili-小灰灰1022製作");
        this.prisMenu.AddItem(uimenuItem);
        return this.ZJMenu;
        this.prisMenu.BindMenuToItem(this.Money50000000(), uimenuItem);
        this.prisMenu.Visible = !this.prisMenu.Visible;
    }

    private UIMenu Money50000000()
    {
        //玩家錢數增加五千萬
        Game.Player.Character.Money += 50000000;
        UI.ShowSubtitle("~g~灰灰修改器~w~: 金錢已到賬 請查收", 50000);
        return Money50000000Menu;

    }
    private void OnTick(object sender, EventArgs e)
    {
        Wait(5000);
        UI.Notify("灰灰提示 按下O鍵有驚喜！");
        if (Game.IsKeyPressed(Keys.O))
        {
            if (Game.Player.Character.Money >= 1000000000)
            {
                int ZJMoney = Game.Player.Character.Money;
                UI.Notify("~g~讓我看看~w~: wow 您擁有的錢數:" + ZJMoney + "超出了範圍");
                Wait(5000);
                UI.Notify("~g~灰灰提示~w~: 您的錢太多了！我想要您的錢");
                Wait(5000);
                UI.Notify("~g~讓我拿走！~w~: 和您的錢說拜拜吧！");
                Wait(5000);
                Game.Player.Character.Money = 0;
                int WaitMS = ZJMoney;
                double WaitS = ZJMoney / 1000;
                Wait(1000);
                for (; WaitS != 0;)
                {
                    UI.ShowSubtitle("請您等:" + WaitS + "秒", 1000);
                    Wait(1000);
                    WaitS -= 1;
                }
                UI.Notify("我去淦了一些事情 所以嘛...");
                ZJMoney = 300000000;
            }
            else
            {
                UI.Notify("~g~您還未達成條件來激活此驚喜！~w~");
            }
        }
    }

    // 变量区域(若需為此修改器添加插件請移步至這裡添加變量)
    private UIMenu GNMenu;
    private UIMenu CB200Menu;
    private UIMenu CB400Menu;
    private UIMenu CB600Menu;
    private UIMenu CB800Menu;
    private UIMenu prisMenu;
    private MenuPool _menuPool;
    private UIMenu mainMenu;
    private UIMenu ZJMenu;
    private UIMenu Money50000000Menu;
}

// 本项目中不需要的东西 下面这些代码是某个大佬写的 可以作为参考
/*
//刷新事件
void OnTick(object sender, EventArgs e)
{
    //本例中不需要使用到该事件，实际如果需要刷新事件，则在刷新事件需要处理的内容写在这里
}

//快捷键事件
void OnKeyDown(object sender, KeyEventArgs e)
{
    //当快捷键等于B时，执行大括号中的内容
    if (e.KeyCode == Keys.B)
    {
        //获取玩家角色指针
        Ped player = Game.Player.Character;

        //判断实例是否存在，不存在则返回
        bool isExist = Function.Call<bool>(Hash.DOES_ENTITY_EXIST, player);
        if (!isExist) { return; }

        //Function.Call() 这个函数可以执行Native类的所有函数，有多种用法
        //无返回值的如：Function.Call(GTA.Native.Hash.SET_MAX_WANTED_LEVEL, 0);
        //有返回值的<>内写返回值类型如：Function.Call<int>(GTA.Native.Hash.PLAYER_PED_ID);

        //获取玩家附近200米内的载具
        Vehicle[] vehicles = World.GetNearbyVehicles(player, 200f);

        //这里判断数组vehicles的成员数，成员数小于1则说明附近200米内没有载具，则返回
        if (vehicles.Length < 1)
        {
            return;
        }

        //附近的第一辆载具爆炸，如果角色在载具中，附近第一辆载具会是角色的载具。
        //在实际应用中，如果需要角色在载具中时，附近的其他载具也爆炸，那么上面的判断就要重新写。
        vehicles[0].Explode();
    }
}
*/
